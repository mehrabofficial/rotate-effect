import "./App.css"

const App = () => {
  return (
    <>
    <div className="container">
       Lorem ipsum dolor sit amet consectetur adipisicing elit. Quidem perferendis maxime quam optio voluptatibus culpa amet possimus fuga eaque a!
    </div>
    
    </>
  )
}

export default App